package com.renault.main;

public class ReadingData {
	public static void main(String[] args) {
		
	}

}
